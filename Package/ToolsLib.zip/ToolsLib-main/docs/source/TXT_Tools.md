## TXT_Tools

 read_lines(txt_path,split_flag=None)

```
批量读取多行
txt_path: txt路径
split_flag: 分隔符(可选),每行按指定字符分割
```



write_lines(lines,txt_path)

```
 批量写入多行
 lines: 待写入的list
 txt_path: txt保存路径
```








​        