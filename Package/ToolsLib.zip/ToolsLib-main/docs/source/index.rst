.. ToolsLib documentation master file, created by
   sphinx-quickstart on Tue Feb 15 11:49:32 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ToolsLib's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Img_Tools
   List_Tools
   TXT_Tools




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
