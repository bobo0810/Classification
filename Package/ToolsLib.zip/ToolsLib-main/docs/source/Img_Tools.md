##  Img_Tools

down_urls(url_list, save_path, time=5)

```
 根据url下载图片,随机uuid命名。
 
 url_list(list): URL列表 eg:['http://a.jpg', http://aaacc', ...]
 save_path(str): 图像保存路径
 time(int可选):耗时限制，单位s
```



plot_bbox(img,bbox,name,prob)

```
绘制bbox后返回npy

img(numpy): cv2读取的图像[H,W,C]
bbox(list):  锚框归一化后的坐标[N,4]. 即中心点坐标xy、锚框宽高wh. eg:[[0.61,0.64,0.12,0.20],...]
name(list): 锚框对应类别[N]. eg:['cat', 'dog', ...]
prob(list): 锚框对应概率[N]. eg:[0.9, 0.8, ...]

return
img(numpy): 已绘制的图像[H,W,C]
```



filter_md5(imgs_list,compare_list=[])

```
基于md5对imgs_list图像自身去重，返回重复图像的列表

imgs_list(list): 待去重的图像路径列表
compare_list(list可选): 基于对比库再去重。
注：若文件读取出错，则过滤掉
```

verify_integrity(imgs_list)
```
验证图像完整性

imgs_list(list): 包含图像绝对路径的列表。 eg:[/home/a.jpg,...]

return
error_list(list): 错误图像的列表。eg:[/home/a.jpg,...]
```